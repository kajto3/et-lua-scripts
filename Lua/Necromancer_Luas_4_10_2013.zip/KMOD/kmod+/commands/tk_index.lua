-- !tk_index
function dolua(params) 
	if (params.slot != CONSOLE ) then
		-- make it look like the player has used the command in chat
		userPrint(params.slot,params.chat,et.ConcatArgs(1),-1)


		local status = ""
		local PlayerID = params.slot
		local name = et.Info_ValueForKey( et.trap_GetUserinfo( PlayerID ), "name" )
		if teamkillr[PlayerID] < -1 then
			status = "^1NOT OK"
		else
			status = "^2OK"
		end
		et.trap_SendServerCommand( PlayerID, "b 8 \"^3Tk_index: ^7" .. name .. "^7 has a tk index of ^3" ..teamkillr[PlayerID] .. "^7 \[" .. status .. "^7\] \"" )
		return 1
	end
end