-- random spawn
module_name = "Random Spawn"
module_version = 0.1

Spawns = "Spawns" -- the name of the folder where the spawns for the maps are located


RADIUS = 1200 -- how close an *enemy* player needs to be so the player won't spawn at this spawn point.
-- note that if all spawn points are "closed" due to enemy proximity, it will spawn the player randomly regardelss of enemy positions.


ALLIES = 1
AXIS = 2

function et_ClientSpawn(slot, revived )
	if revived == 0 then
		--et.G_Print("test2: ".. table.getn(SPAWN) .. "\n")
		spawns = availableSpawns(SPAWN, et.gentity_get(slot,"sess.sessionTeam"))
		spawn = randomSpawn(spawns)
		et.gentity_set(slot, "origin", spawn)
	end
end

--dist = calcDist(player_pos, spawn.pos)

function calcDist(pos1, pos2)
	--et.G_Print("test: ".. table.getn(SPAWN) .. "\n")
	local dist2 = (pos1[1]-pos2[1])^2 + (pos1[2]-pos2[2])^2 
                  + ((pos1[3]-pos2[3])*2)^2
    return math.sqrt(dist2)
end

function availableSpawns(spawn,team)
	-- init spawns
	if spawn == nil then
		et.G_LogPrint("RS - no spawns defined for this map\n" )
		return
	end
	for i=1,table.getn(spawn),1 do
		spawn[i]["flag"] = 0
	end
	

	for i=0, tonumber(et.trap_Cvar_Get("sv_maxclients"))-1, 1 do
		if et.gentity_get(i, "health") > 0 then -- alive
			player_team = et.gentity_get(i,"sess.sessionTeam")
			if  player_team ~= team and player_team ~= 0 and player_team ~= SPEC then
				player = et.gentity_get(i, "origin")
				stop = table.getn(spawn)
				j=1 
				while j<=stop do
					--et.G_Print("i = " .. j .. "\n")
					--for k,v in ipairs(spawn[j]) do print(k,v) end
					
					if calcDist(spawn[j],player) < RADIUS then
						table.remove(spawn,j)
						j = j-1 -- the table shifts, dont increase the counter
						stop = stop -1
			
					end
					--et.G_Print("stop = " .. stop .. "\n")
					--et.G_Print("------------------------\n")
					j= j+1
				end
			end
		end
	end
	if table.getn(spawn) <= 0 then -- nowhere to spawn, everything available!
		spawn = SPAWN
	end
	return spawn
end

function randomSpawn(spawn)
	return spawn[math.random(table.getn(spawn))]
end

function getConfig(map)
	local filename = et.trap_Cvar_Get("fs_homepath")
	filename = filename .. '/' ..et.trap_Cvar_Get("gamename") .. '/' ..  Spawns .. '/' .. map .. ".lua"

	hasconfig = false 
	setSpawns = nil
	-- use this to debug your commands. assert prints the error. (remove assert to not-display script errors)
	local f = pcall(loadfile(filename))

	
	if (f == true ) then
		
		if  type(f) ~= "function" then
			f = assert(loadfile(filename))
		end
		pcall(f) -- define the setSpawns function
		if (type(setSpawns) ~= "function") then -- the setSpawns function is not defind in that script

			local fd = io.open( filename, "r")
			local filestr =  fd:read("*a")
			fd:close()

			-- for some reason this code doesnt work in some cases... etpro says "cannot malloc -1 bytes" - forward to the etpro team?
			--local fd,len = et.trap_FS_FOpenFile( 'kmod/commands/' .. command .. ".lua", et.FS_READ )
			--if (len > 0) then
			--et.G_Print(command .. "\n")
			--local filestr = et.trap_FS_Read( fd, len ) 
			assert(loadstring('function setSpawns() ' .. filestr .. "\nend","f"))() -- wrap the file in the dolua(params) function, and run the chunk (define the function)

		end


		if (type(setSpawns) == "function") then
			hasconfig = true -- we got a map spawn config!
			--return setSpawns() -- run the code
			--et.G_Print("map defined!\n")
		else
			
			et.G_LogPrint("RS - no spawns defined for map " ..map.. "\n" )
		end



	else  -- the file does not exist (or any other error loading the file)
		et.G_LogPrint("RS - no spawns defined for map " ..map.. "\n" )
	end	

end

function et_InitGame( levelTime, randomSeed, restart)
    local modname = string.format("%s v%s", module_name, module_version)
    et.G_Print(string.format("%s loaded\n", modname))
    et.RegisterModname(module_name)

    mapname = et.trap_Cvar_Get("mapname")
    getConfig(mapname) -- load the map config!
end