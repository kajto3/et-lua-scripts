----------------------------------
--------  XP Reset Module --------
--------  www.usef-et.org --------
--------  By Necromancer  --------
--------     4/1/2009     --------
----------------------------------


LEVEL = {}
-- default MAX_XP 
LEVEL.DEFAULT = 10000
--LEVEL[level_number] = max_xp
LEVEL[3] = 15000
LEVEL[6] = 15000
LEVEL[9] = 15000
LEVEL[15] = 15000

-- a value of -1 means never ever reset xp.

-- Suggestion: dont admin abuse this module - dont give high XP reset limit to server admins only.
-- let other players get it too. plus, dont set the highest limit way more then the default on (for the public players that play on your server)
-- if you do so, people might not want to play on your server (i probably wouldnt).
-- this module was originally written to give a bonus to players who are active in our community (active on the forum, voip server, participate in activities etc...)
-- designed for and tested on ETpub 0.9.x


-- anyone may use, change and manipulate this module.

et.trap_Cvar_Set("g_maxXP", -1) -- disable MAX XP reset! this module will handle it from now on.

--XP

function et_RunFrame( levelTime )
	et.G_shrubbot_level( slot )
	for slot=0, tonumber(et.trap_Cvar_Get("sv_maxclients"))-1, 1 do
		if et.Info_ValueForKey( et.trap_GetUserinfo( slot ), "name" )~= "" then  -- an empty player name ==> no player in this slot
			XP = tonumber(et.gentity_get( slot, "ps.persistant", 0 ))
			if XP ~= nil then
				--et.G_LogPrint("XP - " .. XP .. "\n")
				if LEVEL[tonumber(et.G_shrubbot_level( slot ))] == nil then
					if XP >=  LEVEL.DEFAULT then
						resetxp(slot)
					end
				elseif LEVEL[tonumber(et.G_shrubbot_level( slot ))] ~= -1 then
					if XP >= LEVEL[tonumber(et.G_shrubbot_level( slot ))] then
						resetxp(slot)
					end
				end
			end
		end
	end
end
				

function resetxp(slot)
	--et.trap_SendConsoleCommand( et.EXEC_APPEND, "resetxp " .. slot .."\n")
	--et.G_LogPrint("XP has been reset for slot " .. slot .. "\n")

	-- the "hard" way:
	for skill=0,6,1 do -- the classes are numbered from 0 to 6 (7 total, 5 + battle sense + light weapons)
		et.G_LoseSkillPoints(slot, skill, et.gentity_get( slot, "sess.skillpoints", skill)) -- making use of the G_LoseSkillPoints function just for pheno :)
	end
end
		


