------------------------------------------------------------
-----------------   XP Save For ETpro   --------------------
-----------------     By Necromancer    --------------------
-----------------       3/7/2009        --------------------
-----------------    www.usef-et.org    --------------------   
------------------------------------------------------------


-- you may change this module and take stuff from it, and basicly "do what the fuck you want" with it.





MAX_XP = 10000
MAX_XP_TIME = 172800 -- 48 hours

DEBUG = 0


et.trap_Cvar_Set("g_XPSaveMaxAge", MAX_XP_TIME)
et.trap_Cvar_Set("g_maxXP", MAX_XP)














-- Constans
BATTLESENSE = 0
ENGINEERING = 1
MEDIC = 2
SIGNALS = 3
LIGHT_WEAPONS = 4
HEAVY_WEAPONS = 5
COVERT = 6

XP = {}
XP["kill"]= 3 -- 3 xp rewarded for a kill
XP["revive"] = 3 -- 3 xp rewarded for a revive
XP["health"] = 1 -- 1 xp rewarded for a health pack
XP["ammo"] = 1 -- 1 xp rewarded for a ammo pack

----- Defines --------


global_players_table = {}


global_levels_table = {}
global_levels_table[BATTLESENSE] = {}
global_levels_table[ENGINEERING] = {}
global_levels_table[MEDIC] = {}
global_levels_table[SIGNALS] = {}
global_levels_table[LIGHT_WEAPONS] = {}
global_levels_table[HEAVY_WEAPONS] = {}
global_levels_table[COVERT] = {}
i=1
for level in string.gfind(et.trap_Cvar_Get("b_levels_battlesense"), "%s*(-?%d*)") do
	global_levels_table[BATTLESENSE][i] = tonumber(level)
	-- et.G_LogPrint("level - " .. i .. " xp - " ..level .. "\n")
	-- et.G_LogPrint("test3 - " .. type(global_levels_table[1][4]) .. "\n")
	i = i+1
	
end
i=1
for level in string.gfind(et.trap_Cvar_Get("b_levels_engineer"), "%s*(-?%d*)") do
	global_levels_table[ENGINEERING][i] = tonumber(level)
	i = i+1
end
i=1
for level in string.gfind(et.trap_Cvar_Get("b_levels_medic"), "%s*(-?%d*)") do
	global_levels_table[MEDIC][i] = tonumber(level)
	i = i+1
end
i=1
for level in string.gfind(et.trap_Cvar_Get("b_levels_fieldops"), "%s*(-?%d*)") do
	global_levels_table[SIGNALS][i] = tonumber(level)
	i = i+1
end
i=1
for level in string.gfind(et.trap_Cvar_Get("b_levels_lightweapons"), "%s*(-?%d*)") do
	global_levels_table[LIGHT_WEAPONS][i] = tonumber(level)
	i = i+1
end
i=1
for level in string.gfind(et.trap_Cvar_Get("b_levels_soldier"), "%s*(-?%d*)") do
	global_levels_table[HEAVY_WEAPONS][i] = tonumber(level)
	i = i+1
end
i=1
for level in string.gfind(et.trap_Cvar_Get("b_levels_covertops"), "%s*(-?%d*)") do
	global_levels_table[COVERT][i] = tonumber(level)
	i = i+1

end



function ParseString(inputString)
	-- Rany
	inputString = inputString or ""
	local i = 1
	local t = {}
	for w in string.gfind(inputString, "([%S]+)%s*") do
		t[i]=w
		i=i+1
	end
	return t
 end

function et_ClientBegin( clientNum )
	local name = et.Info_ValueForKey( et.trap_GetUserinfo( clientNum ), "name" )
	local guid = string.upper(et.Info_ValueForKey( et.trap_GetUserinfo( clientNum ), "cl_guid" ))

	if  global_players_table[clientNum] == nil then -- how is it possible? see et_ClientSpawn
		global_players_table[clientNum] = {}
	end

	global_players_table[clientNum]["guid"] = guid
	global_players_table[clientNum]["name"] = name
	global_players_table[clientNum]["ip"] = string.gsub(et.Info_ValueForKey( et.trap_GetUserinfo( clientNum ), "ip" ), "%:%d+", "") -- gsub removed the :port from the ip
	global_players_table[clientNum]["team"] = et.gentity_get(clientNum,"sess.sessionTeam")

	

	if global_xp_table[guid] == nil then -- new player (no xp)
		global_xp_table[guid] = {}
		global_xp_table[guid]["name"] = global_players_table[clientNum]["name"]
		global_xp_table[guid][BATTLESENSE] = 0
		global_xp_table[guid][ENGINEERING] = 0
		global_xp_table[guid][MEDIC] = 0
		global_xp_table[guid][SIGNALS] = 0
		global_xp_table[guid][LIGHT_WEAPONS] = 0
		global_xp_table[guid][HEAVY_WEAPONS] = 0
		global_xp_table[guid][COVERT] = 0
		global_xp_table[guid]["xp"] = tonumber(et.gentity_get( clientNum, "ps.persistant", 0 ))
	end

	if  global_xp_table[guid]["xp"] >= tonumber(et.trap_Cvar_Get("g_maxXP")) then -- we need to reset the guys xp
		-- but thats not enough, the reset must be coordinated with the etpro mod, or it wont work (he'll get he awards back)
		if tonumber(et.gentity_get( clientNum, "ps.persistant", 0 )) == 0 then -- ETpro mod has reset his XP! so should we!
			resetxp(guid)
		end
	end

	global_xp_table[guid]["time"] = os.time()


	-- temp xp 
	global_players_table[clientNum]["xp"] = tonumber(et.gentity_get( clientNum, "ps.persistant", 0 ))

	
	update_skills(clientNum)
		
end

function update_skills(slot)
	et.gentity_set( slot, "sess.skill", BATTLESENSE, get_skill_level( BATTLESENSE, global_xp_table[global_players_table[slot]["guid"]][BATTLESENSE]) )
	et.gentity_set( slot, "sess.skill", ENGINEERING, get_skill_level( ENGINEERING,global_xp_table[global_players_table[slot]["guid"]][ENGINEERING]) )
	et.gentity_set( slot, "sess.skill", MEDIC, get_skill_level( MEDIC,global_xp_table[global_players_table[slot]["guid"]][MEDIC]) )
	et.gentity_set( slot, "sess.skill", SIGNALS, get_skill_level( SIGNALS,global_xp_table[global_players_table[slot]["guid"]][SIGNALS]) )
	et.gentity_set( slot, "sess.skill", LIGHT_WEAPONS, get_skill_level( LIGHT_WEAPONS,global_xp_table[global_players_table[slot]["guid"]][LIGHT_WEAPONS]) )
	et.gentity_set( slot, "sess.skill", HEAVY_WEAPONS, get_skill_level( HEAVY_WEAPONS,global_xp_table[global_players_table[slot]["guid"]][HEAVY_WEAPONS]) )
	et.gentity_set( slot, "sess.skill", COVERT, get_skill_level( COVERT,global_xp_table[global_players_table[slot]["guid"]][COVERT]) )
end

function et_InitGame( levelTime, randomSeed, restart )
	et.RegisterModname("xpsave")

	--et.G_LogPrint("test - " .. get_skill_level( ENGINEERING, 30) .. "\n\n")
	load_xp() 
end

function et_Quit() 
	write_xp() 
end


function et_RunFrame( levelTime )
	for i=0, tonumber(et.trap_Cvar_Get("sv_maxclients"))-1, 1 do
		if global_players_table[i] ~= nil then
			updatexp(i)
		end
	end
end


--[[
function et_UpgradeSkill(cno, skill) 
   et.gentity_set( cno, "sess.skill", skill, global_xp_table[global_players_table[slot]["guid"]
   ][tonumber(skill)] ) 
end
--]]


function et_ClientCommand(slot, command) 
	command = string.lower(command) 
	if command == "xp" then 
		et.trap_SendServerCommand(slot, "print \"^3xpsave^f:^3 you have " .. global_xp_table[global_players_table[slot]["guid"]]["xp"] .. "XP out of " .. et.trap_Cvar_Get("g_maxXP") .. "XP allowed\n\"")
		return 1 
	end


end

function updatexp(slot)
	--if global_players_table[clientNum]["resetxp"] == 1 then return end -- dont update if xp needs to be reset


	temp = global_players_table[slot]["xp"]
	global_players_table[slot]["xp"] = tonumber(et.gentity_get( slot, "ps.persistant", 0 ))
	change = global_players_table[slot]["xp"] - temp
	if change > 0 then
		global_xp_table[global_players_table[slot]["guid"]]["xp"] = global_xp_table[global_players_table[slot]["guid"]]["xp"] + change
	end
	
end

function resetxp(guid)
	global_xp_table[guid]["xp"] = 0
	global_xp_table[guid][BATTLESENSE] = 0
	global_xp_table[guid][ENGINEERING] = 0
	global_xp_table[guid][MEDIC] = 0
	global_xp_table[guid][SIGNALS] = 0
	global_xp_table[guid][LIGHT_WEAPONS] = 0
	global_xp_table[guid][HEAVY_WEAPONS] = 0
	global_xp_table[guid][COVERT] = 0

	if DEBUG > 0 then	et.G_LogPrint("xpsave: xp reset for guid: " .. guid .. "\n")		end


end

function get_skill_level(skill,xp) -- gets skill, and the skill's xp, and returns the level the player now has (if i have 50XP, ive got level 2)
	return level4(skill,xp)
end

function level1(skill,xp)
	if global_levels_table[skill][1] == -1 then return 0 
	elseif xp >= global_levels_table[skill][1] then return 1
	else return 0
	end
end

function level2(skill,xp)
	if global_levels_table[skill][2] == -1 then return level1(skill,xp) 
	elseif xp >= global_levels_table[skill][2] then return 2
	else return level1(skill,xp)
	end
end

function level3(skill,xp)
	if global_levels_table[skill][3] == -1 then return level2(skill,xp) 
	elseif xp >= global_levels_table[skill][3] then return 3
	else return level2(skill,xp)
	end
end

function level4(skill,xp)
	if global_levels_table[skill][4] == -1 then return level3(skill,xp) 
	elseif xp >= global_levels_table[skill][4] then return 4
	else return level3(skill,xp) 
	end
end
	


function et_UpgradeSkill( slot, skill )
	if DEBUG > 0 then	et.G_LogPrint("xpsave: et_UpgradeSkill called!! - " .. skill .. "\n")		end

	--local temp = et.gentity_get( cno, "ps.persistant", 0 )
	--et.G_LogPrint("test2 - " .. temp .. "\n")

	-- update singe skill
	-- skill = tonumber(skill)
	-- local level
	-- level = et.gentity_get( slot, "sess.skill", skill)
	-- if global_xp_table[global_players_table[slot]["guid"]][skill] > level then
	-- 	et.G_LogPrint("xpsave set!!!\n")
	-- 	et.gentity_set( slot, "sess.skill", skill, global_xp_table[global_players_table[slot]["guid"]][skill] )
	-- elseif global_xp_table[global_players_table[slot]["guid"]][skill] < level then
	-- 	global_xp_table[global_players_table[slot]["guid"]][skill] = level
	-- 	et.G_LogPrint("xpsave updated!!!\n")
	-- end

	
	-- update all skills
	for skill=0,6,1 do
		level = et.gentity_get( slot, "sess.skill", skill)
		if get_skill_level(skill, global_xp_table[global_players_table[slot]["guid"]][skill]) > level then
			if DEBUG > 0 then	et.G_LogPrint("xpsave set!!!\n")	end
			et.gentity_set( slot, "sess.skill", skill, get_skill_level(skill,global_xp_table[global_players_table[slot]["guid"]][skill]) )
		elseif get_skill_level(skill, global_xp_table[global_players_table[slot]["guid"]][skill]) < level then
			global_xp_table[global_players_table[slot]["guid"]][skill] = global_levels_table[skill][level]
			if DEBUG > 0 then	et.G_LogPrint("xpsave updated!!!\n")	end
		end
	end
		

end





-- functions mapping the xp


function et_Print( text )
	local t = ParseString(text)

	if t[1] == "Medic_Revive:" then
		local reviver = tonumber(t[2])
		global_xp_table[global_players_table[reviver]["guid"]][MEDIC] = global_xp_table[global_players_table[reviver]["guid"]][MEDIC] + XP["revive"]

		if DEBUG > 1 then	et.G_LogPrint("xpsave: xp awarded to client " .. reviver .. " for a revive \n\n") end
	end
	--Ammo_Pack: 4 2
	if t[1] == "Ammo_Pack:" then
		local giver = tonumber(t[2])
		global_xp_table[global_players_table[giver]["guid"]][SIGNALS] = global_xp_table[global_players_table[giver]["guid"]][SIGNALS] + XP["ammo"]

		if DEBUG > 1 then	et.G_LogPrint("xpsave: xp awarded to client " .. reviver .. " for a ammo pack \n\n") end
	end
	-- Health_Pack: 4 2
	if t[1] == "Health_Pack:" then
		local giver = tonumber(t[2])
		global_xp_table[global_players_table[giver]["guid"]][MEDIC] = global_xp_table[global_players_table[giver]["guid"]][MEDIC] + XP["health"]

		if DEBUG > 1 then	et.G_LogPrint("xpsave: xp awarded to client " .. reviver .. " for a health pack \n\n") end
	end
end

			

function et_Obituary( victim, killer, meansOfDeath )
	local victimteam = tonumber(et.gentity_get(victim, "sess.sessionTeam")) 
	local killerteam = tonumber(et.gentity_get(killer, "sess.sessionTeam"))

	if victimteam ~= killerteam and killer ~= 1022 and killer ~= victim then
		local skill = weapon_skill(meansOfDeath)
		if skill == nil then return end
		global_xp_table[global_players_table[killer]["guid"]][skill] = global_xp_table[global_players_table[killer]["guid"]][skill] + XP["kill"] 
	end
end

function weapon_skill(meansOfDeath)
	if (meansOfDeath==0) then
		weapon="UNKNOWN"
	elseif (meansOfDeath==1) then
		weapon="MACHINEGUN"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==2) then
		weapon="BROWNING"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==3) then
		weapon="MG42"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==4) then
		weapon="GRENADE"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==5) then
		weapon="ROCKET"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==6) then
		weapon="KNIFE"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==7) then
		weapon="LUGER"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==8) then
		weapon="COLT"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==9) then
		weapon="MP40"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==10) then
		weapon="THOMPSON"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==11) then
		weapon="STEN"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==12) then
		weapon="GARAND"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==13) then
		weapon="SNOOPERSCOPE"
		return COVERT
	elseif (meansOfDeath==14) then
		weapon="SILENCER"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==15) then
		weapon="FG42"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==16) then
		weapon="FG42SCOPE"
		return COVERT
	elseif (meansOfDeath==17) then
		weapon="PANZERFAUST"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==18) then
		weapon="GRENADE_LAUNCHER"
		return ENGINEERING
	elseif (meansOfDeath==19) then
		weapon="FLAMETHROWER"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==20) then
		weapon="GRENADE_PINEAPPLE"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==21) then
		weapon="CROSS"
	elseif (meansOfDeath==22) then
		weapon="MAPMORTAR"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==23) then
		weapon="MAPMORTAR_SPLASH"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==24) then
		weapon="KICKED"
	elseif (meansOfDeath==25) then
		weapon="GRABBER"
	elseif (meansOfDeath==26) then
		weapon="DYNAMITE"
		return ENGINEERING
	elseif (meansOfDeath==27) then
		weapon="AIRSTRIKE"
		return SIGNALS
	elseif (meansOfDeath==28) then
		weapon="SYRINGE"
		return MEDIC
	elseif (meansOfDeath==29) then
		weapon="AMMO"
		return SIGNALS
	elseif (meansOfDeath==30) then
		weapon="ARTY"
		return SIGNALS
	elseif (meansOfDeath==31) then
		weapon="WATER"
	elseif (meansOfDeath==32) then
		weapon="SLIME"
	elseif (meansOfDeath==33) then
		weapon="LAVA"
	elseif (meansOfDeath==34) then
		weapon="CRUSH"
	elseif (meansOfDeath==35) then
		weapon="TELEFRAG"
	elseif (meansOfDeath==36) then
		weapon="FALLING"
	elseif (meansOfDeath==37) then
		weapon = "SUICIDE"
	elseif (meansOfDeath==38) then
		weapon="TARGET_LASER"
	elseif (meansOfDeath==39) then
		weapon="TRIGGER_HURT"
	elseif (meansOfDeath==40) then
		weapon="EXPLOSIVE"
	elseif (meansOfDeath==41) then
		weapon="CARBINE"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==42) then
		weapon="KAR98"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==43) then
		weapon="GPG40"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==44) then
		weapon="M7"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==45) then
		weapon="LANDMINE"
		return ENGINEERING
	elseif (meansOfDeath==46) then
		weapon="SATCHEL"
		return COVERT
	elseif (meansOfDeath==47) then
		weapon="TRIPMINE"
		return ENGINEERING
	elseif (meansOfDeath==48) then
		weapon="SMOKEBOMB"
		return COVERT
	elseif (meansOfDeath==49) then
		weapon="MOBILE_MG42"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==50) then
		weapon="SILENCED_COLT"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==51) then
		weapon="GARAND_SCOPE"
		return COVERT
	elseif (meansOfDeath==52) then
		weapon="CRUSH_CONSTRUCTION"
		return ENGINEERING
	elseif (meansOfDeath==53) then
		weapon="CRUSH_CONSTRUCTIONDEATH"
	elseif (meansOfDeath==54) then
		weapon="CRUSH_CONSTRUCTIONDEATH_NOATTACKER"
	elseif (meansOfDeath==55) then
		weapon="K43"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==56) then
		weapon="K43_SCOPE"
		return COVERT
	elseif (meansOfDeath==57) then
		weapon="MORTAR"
		return HEAVY_WEAPONS
	elseif (meansOfDeath==58) then
		weapon="AKIMBO_COLT"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==59) then
		weapon="AKIMBO_LUGER"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==60) then
		weapon="AKIMBO_SILENCEDCOLT"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==61) then
		weapon="AKIMBO_SILENCEDLUGER"
		return LIGHT_WEAPONS
	elseif (meansOfDeath==62) then
		weapon="SMOKEGRENADE"
		return COVERT
	elseif (meansOfDeath==63) then
		weapon="SWAP_SPACES"
	elseif (meansOfDeath==64) then
		weapon="SWITCH_TEAM"
	end
end

function load_xp() 

	local fd, len = et.trap_FS_FOpenFile('xpsave.cfg', et.FS_READ )
	if len == -1 then -- no xpsave.cfg file
		et.trap_FS_FCloseFile( fd )
		return -1 
	end 
	local filestr = et.trap_FS_Read( fd, len )
	et.trap_FS_FCloseFile( fd )
	global_xp_table = {}

	if DEBUG > 0 then	et.G_LogPrint("xpsave: loading xp!!! \n\n")	end

--[[
[xpsave]
guid              = 9A254288A89F5184FF619DDE178C1B2A
name              = ^0A^7|^0S^7aT^dI^0$^7Fa^dc^0tioN
time              = 1236294767
skill[0]          = 4112.000000
skill[1]          = 601.184082
skill[2]          = 583.000000
skill[3]          = 1.000000
skill[4]          = 2193.000000
skill[5]          = 72.000000
skill[6]          = 230.000000
--]]

--[[
	et.G_LogPrint("xpsave - \n" .. filestr .. "\n")
	for guid,name,ttime,battle_sense in string.gfind(filestr, "%s*\%[xpsave%]%s*guid%s*=%s*(%x*)%s*name%s*=%s*([^%\n]*)%s*time%s*=%s*([^%\n]*)%s*skill\%[0%]%s*=%s*([^%\n]*)%s*") do
		global_xp_table[guid] = {}
		et.G_LogPrint("xpsave loaded xp - " .. guid .. "\n")
	end

--]]
	for guid,name,ttime,battle_sense,eng,medic,signals,light_weapons,heavy_weapons,covert,xp in string.gfind(filestr, "%s*\%[xpsave%]%s*guid%s*=%s*(%x*)%s*name%s*=%s*([^%\n]*)%s*time%s*=%s*([^%\n]*)%s*skill\%[0%]%s*=%s*([^%\n]*)%s*skill\%[1%]%s*=%s*([^%\n]*)%s*skill\%[2%]%s*=%s*([^%\n]*)%s*skill\%[3%]%s*=%s*([^%\n]*)%s*skill\%[4%]%s*=%s*([^%\n]*)%s*skill\%[5%]%s*=%s*([^%\n]*)%s*skill\%[6%]%s*=%s*([^%\n]*)%s*xp%s*=%s*([^%\n]*)%s*") do
		
		
		global_xp_table[guid] = {}
		global_xp_table[guid]["name"] = name
		global_xp_table[guid]["time"] = tonumber(ttime)
		global_xp_table[guid][BATTLESENSE] = tonumber(battle_sense)
		global_xp_table[guid][ENGINEERING] = tonumber(eng)
		global_xp_table[guid][MEDIC] = tonumber(medic)
		global_xp_table[guid][SIGNALS] = tonumber(signals)
		global_xp_table[guid][LIGHT_WEAPONS] = tonumber(light_weapons)
		global_xp_table[guid][HEAVY_WEAPONS] = tonumber(heavy_weapons)
		global_xp_table[guid][COVERT] = tonumber(covert)
		global_xp_table[guid]["xp"] = tonumber(xp)

		if DEBUG > 0 then
			et.G_LogPrint("xpsave: loaded xp for guid - " .. guid .. "\n")
			et.G_LogPrint("xpsave: loaded xp - " .. global_xp_table[guid]["xp"] .. "\n")
			et.G_LogPrint("xpsave: loaded skill[0] - " .. global_xp_table[guid][BATTLESENSE] .. "\n")
			et.G_LogPrint("xpsave: loaded skill[1] - " .. global_xp_table[guid][ENGINEERING] .. "\n")
			et.G_LogPrint("xpsave: loaded skill[2] - " .. global_xp_table[guid][MEDIC] .. "\n")
			et.G_LogPrint("xpsave: loaded skill[3] - " .. global_xp_table[guid][SIGNALS] .. "\n")
			et.G_LogPrint("xpsave: loaded skill[4] - " .. global_xp_table[guid][LIGHT_WEAPONS] .. "\n")
			et.G_LogPrint("xpsave: loaded skill[5] - " .. global_xp_table[guid][HEAVY_WEAPONS] .. "\n")
			et.G_LogPrint("xpsave: loaded skill[5] - " .. global_xp_table[guid][COVERT] .. "\n")
		end

	end


end

function write_xp() 
	local fd, len = et.trap_FS_FOpenFile('xpsave.cfg', et.FS_WRITE )
	if len == -1 then -- no xpsave.cfg file
		et.trap_FS_FCloseFile( fd )
		return -1 
	end 
	local i,text, save_time
	save_time = tonumber(et.trap_Cvar_Get("g_XPSaveMaxAge"))
	if save_time == nil then t.G_LogPrint("xpsave ERROR - g_XPSaveMaxAge is not set!\n") end

	
	for guid,v in pairs(global_xp_table) do
		if os.time() - ( global_xp_table[guid]["time"] + save_time) > 0 then
			-- do nothing. dont save it, too much time has passed.
		else
			--[[ resetting the xp must be coordinated with the ETPro mod!!!
			if  global_xp_table[guid]["xp"] >= tonumber(et.trap_Cvar_Get("g_maxXP")) then
				resetxp(guid)
			end
			--]]
			text = "[xpsave]\n"
			text = text .. string.format("%-18s = %s\n","guid",guid)
			text = text .. string.format("%-18s = %s\n","name",global_xp_table[guid]["name"])
			text = text .. string.format("%-18s = %s\n","time",global_xp_table[guid]["time"])
			text = text .. string.format("%-18s = %s\n","skill[0]",global_xp_table[guid][BATTLESENSE])
			text = text .. string.format("%-18s = %s\n","skill[1]",global_xp_table[guid][ENGINEERING])
			text = text .. string.format("%-18s = %s\n","skill[2]",global_xp_table[guid][MEDIC])
			text = text .. string.format("%-18s = %s\n","skill[3]",global_xp_table[guid][SIGNALS])
			text = text .. string.format("%-18s = %s\n","skill[4]",global_xp_table[guid][LIGHT_WEAPONS])
			text = text .. string.format("%-18s = %s\n","skill[5]",global_xp_table[guid][HEAVY_WEAPONS])
			text = text .. string.format("%-18s = %s\n","skill[6]",global_xp_table[guid][COVERT])
			text = text .. string.format("%-18s = %s\n","xp",global_xp_table[guid]["xp"])
			text = text .."\n"
			et.trap_FS_Write( text, string.len(text) ,fd )

			if DEBUG > 0 then
				et.G_LogPrint("xpsave saved xp - " .. global_xp_table[guid]["xp"] .. "\n")
				et.G_LogPrint("xpsave saved skill[0] - " .. global_xp_table[guid][BATTLESENSE] .. "\n")
				et.G_LogPrint("xpsave saved skill[1] - " .. global_xp_table[guid][ENGINEERING] .. "\n")
				et.G_LogPrint("xpsave saved skill[2] - " .. global_xp_table[guid][MEDIC] .. "\n")
				et.G_LogPrint("xpsave saved skill[3] - " .. global_xp_table[guid][SIGNALS] .. "\n")
				et.G_LogPrint("xpsave saved skill[4] - " .. global_xp_table[guid][LIGHT_WEAPONS] .. "\n")
				et.G_LogPrint("xpsave saved skill[5] - " .. global_xp_table[guid][HEAVY_WEAPONS] .. "\n")
				et.G_LogPrint("xpsave saved skill[5] - " .. global_xp_table[guid][COVERT] .. "\n")
			end


		end
	end
	et.trap_FS_FCloseFile( fd )
end

