-- this module restricts the use of individual commands only for admins that knows the password (used against guid spoofers).


PASSWORD = "b4d" -- passowrd admin needs to enter in order to authorize himself
PASSWORD_COMMAND = "pass" -- the command: /pass xxx (pass is the command for authorization)
LEVEL = 9 -- from what level and higher authorization is required
WRONG = 5 -- after this many times that an un-authorized admin tries to execute a passworded command he will be kicked

k_commandprefix = "!" -- command prefix
CVAR = "cmdpass" -- the name of the cvar saving the slots
AUTHORIZED = {}

SILENT = 1
CHAT = 0

COMMANDS = {} -- commands that require password
COMMANDS["kick"] = 1
COMMANDS["ban"] = 1
COMMANDS["setlevel"] = 1
COMMANDS["flinga"] = 1
COMMANDS["throwa"] = 1
COMMANDS["launcha"] = 1
COMMANDS["pip"] = 1
COMMANDS["pop"] = 1
COMMANDS["gib"] = 1
COMMANDS["slap"] = 1
COMMANDS["burn"] = 1
COMMANDS["lol"] = 1
COMMANDS["pause"] = 1
COMMANDS["disorient"] = 1
COMMANDS["nextmap"] = 1
COMMANDS["resetxp"] = 1
COMMANDS["reset"] = 1
COMMANDS["restart"] = 1
COMMANDS["shuffle"] = 1
COMMANDS["passvote"] = 1



function et_InitGame( levelTime, randomSeed, restart )
	local slot
	for slot=0, tonumber(et.trap_Cvar_Get("sv_maxclients"))-1, 1 do
	-- load any authorized admins from last map
		if Cvar.Slot_Exists(CVAR,slot) ~=nil then
			AUTHORIZED[slot] = 1
		end
	end
end


function et_ClientCommand( slot, command )
	local arg0 = string.lower(et.trap_Argv(0))
	local password = string.lower(et.trap_Argv(1))

	-- authorizing the admin
	if command == PASSWORD_COMMAND or arg0 == PASSWORD_COMMAND then
		if PASSWORD == password then
			if AUTHORIZED[slot] == nil or AUTHORIZED[slot] <= 0 then
				AUTHORIZED[slot] = 1
				Cvar.Add_Slot(CVAR,slot)
				et.trap_SendServerCommand(slot, string.format("print \"^fYou are now authorized to use all commands!\n"))
				return 1
			else 
				et.trap_SendServerCommand(slot, string.format("print \"^fYou are already authorized to use all commands!\n"))
				return 1
			end
		end
	end

	-- catching admin command
	local s,e,command
	if et.G_shrubbot_level( slot ) >= LEVEL then -- high admin that needs to be checked.
		if AUTHORIZED[slot] == nil or AUTHORIZED[slot] <= 0 then -- un authorized admin
			s,e,command = string.find(et.ConcatArgs(1), k_commandprefix .. "([%S]*)")
			ss,se,silent_command = string.find(string.lower(et.trap_Argv(0)), k_commandprefix .. "(%S+)")
			if (s==1 and e) or (ss==1 and se) then -- its an admin command
				local ctype -- command type (chat or silent)
				if command ~= nil then 
					command = string.lower(command) 
					ctype = CHAT
				end
				if silent_command ~= nil then 
					silent_command = string.lower(silent_command) 
					ctype = SILENT
				end
				for CMD,enable in pairs(COMMANDS) do
					if (CMD == command) or (CMD == silent_command) and enable ~= 0 then
						
						if ctype == CHAT then
							et.G_LogPrint("cmdpass - un authorized command detected: " .. command .. " from slot: " .. slot .."\n")
						else
							et.G_LogPrint("cmdpass - un authorized silent command detected: " .. silent_command .. " from slot: " .. slot .."\n")
						end
						
						if AUTHORIZED[slot] == nil then AUTHORIZED[slot] = 0 
						else AUTHORIZED[slot] = AUTHORIZED[slot] -1 end

						if AUTHORIZED[slot] <= (-1)*WRONG then
							et.G_LogPrint("cmdpass - admin kicked: " .. slot .."\n")
							et.trap_DropClient( slot, "you are not welcome here.\n")

						end

						return 1 -- un authorized admin using passworded command!
					end
				end
			end
		end
	end
end


function et_ClientDisconnect( slot )
	-- client disconnected - un authrize him

	-- un-authorize from current table
	AUTHORIZED[slot] = nil

	 -- un-authorize from cvar string
	Cvar.Remove_Slot(CVAR,slot)
end





-- utils
Cvar = {}
function Cvar.Add_Slot(cvar,slot) -- adds the slot to the cvar, returns 1 on success, or nil otherwise (returns nil if its already in)
	--et.trap_Cvar_Set( cvar, et.trap_Cvar_Get(cvar) .. " " .. slot ) -- every time it appends a space to the start, eventually the cvar will explode.
	if Cvar.Slot_Exists(cvar,slot) then return nil end

	et.trap_Cvar_Set(cvar, table.concat(Cvar.Slots_Table(cvar), " ") .. " " ..slot )
	return 1

end

function Cvar.Remove_Slot(cvar,slot) -- removes a slot, returns 1 on seccess, or nil otherwise (if it doesnt exist)
	local t = Cvar.Slots_Table(cvar)
	local i,index
	if type(t) == "table" then 
		index = Cvar.Slot_Exists(cvar,slot)
		if index == nil then return nil end -- slot doesnt exist.
		table.remove (t , index)
		et.trap_Cvar_Set(cvar, table.concat(t, " "))
		return 1
	else -- its already empty
		et.trap_Cvar_Set(cvar, "")
		return nil 
	end


end

function Cvar.Slot_Exists(cvar,slot) -- checks if the slot exists, returns its index position in the slots table, or nil otherwise
	local flag = nil
	local t = Cvar.Slots_Table(cvar)
	for i=1,table.getn(t), 1 do
		if ( slot == t[i] ) then
			return i
		end
	end
	return nil
end

function Cvar.Slots_Table(cvar) -- returns a table containing all slots 
	local cvar = et.trap_Cvar_Get(cvar)
	local slot
	local i = 1
	local t = {}
	for slot in string.gfind(cvar, "%s*(%d+)") do
		t[i]=tonumber(slot)
		i=i+1
	end
	return t
end