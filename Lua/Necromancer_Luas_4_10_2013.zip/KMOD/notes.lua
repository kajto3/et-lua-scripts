---------------------------------------
---------	Notes	    -----------
---------  By Necromancer   -----------
---------    03/03/2009     -----------
---------------------------------------


-- sends notes to users, by levels.

MOD = et.trap_Cvar_Get("gamename")


function et_InitGame( levelTime, randomSeed, restart )
	et.RegisterModname("notes")
	loadnotes()
end

function et_ClientBegin( slot )
	
	if notes == nil then return end -- notes did not load, file is propobly missing.
	local i,j
	local position, prefix
	j = 1
	message = ""
	for i=1,table.getn(notes),1 do
		--et.G_LogPrint("note loop - notes[" .. i .. "][\"levels\"][".. et.G_shrubbot_level( slot ) .. "]" ..  " \n")
		--et.G_LogPrint("note loop - " .. type(notes[i]["levels"][8]) ..  " \n")
		--if notes[i]["levels"][8] then et.G_LogPrint("hello\n") end
		if notes[i]["levels"][et.G_shrubbot_level( slot )] then
			--et.G_LogPrint("note - " .. et.G_shrubbot_level( slot ) .. " \n")
			position = "b " .. notes[i]["position"]
			if  MOD == "etpub" then 
				position = notes[i]["position"]
			end
			if math.fmod(j,2)== 0 then
				prefix = "^hN^mote " .. "^h"..j .. "^m:^w "
			else
				prefix = "^mN^hote " .. "^m"..j .. "^h:^w "
			end
			--et.G_LogPrint("note - " .. slot .. " - " .. notes[i]["message"] .. "\n")
			et.trap_SendServerCommand( slot , string.format('%s \"%s\"',position, prefix .. notes[i]["message"]))
			j = j+1
		end
	end
end

function loadnotes()
	local fd, len = et.trap_FS_FOpenFile( "notes.cfg" , et.FS_READ )
	if (len == nil or len < 0 ) then
		et.trap_FS_FCloseFile( fd )
		return
	end
	local filestr = et.trap_FS_Read( fd, len )
	et.trap_FS_FCloseFile( fd )

	local i=1
	local position = ""
	notes = {}
	for message,levels,position in string.gfind(filestr, "%s*\%[note%]%s*message%s*=%s*([^%\n]*)%s*levels%s*=%s*([^%\n]*)%s*position%s*=%s*([%S]*)%s*") do
		notes[i] = {}
		notes[i]["levels"] = {}
		notes[i]["message"] = string.gsub(string.gsub(message, "\"",""),"\r","")

		for level in string.gfind(levels, "(-?%d+)") do
			notes[i]["levels"][tonumber(level)] = true
			--et.G_LogPrint("note loaded - notes[" .. i .. "][\"levels\"][".. tonumber(level) .. "]" ..  " \n")
		end

		if (tonumber(position) == nil) then -- its a string, change it
			--position = string.sub(position,1,-2)
			if et.trap_Cvar_Get("gamename") ~= "etpub" then 
				if (position == "chat") then
					position = "8"
				elseif (position == "cpm") then
					position = "16"
				elseif (position == "cp") then
					position = "32"
				elseif (position == "bp") then
					position = "128"
				else 
					et.G_LogPrint("LUA - notes: note ".. i .. " uknown position " .. position .. "\n")
					return
				end
			end
		end
		notes[i]["position"] = position
		i=i+1
		
	end
end