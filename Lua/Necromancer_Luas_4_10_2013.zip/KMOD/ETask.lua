--------------------------------------------------------------------------------
-- ET:Ask -Enemy Territory Anti-Spawnkill Mod for 
-- created by [ETW-FZ] Mad@Mat (http://etw-funzone.eu/)
-- modefied by Necromancer (www.usef-et.org)
-- 23/03/09
-- tested and worked on ETpub and ETpro mods.

--------------------------------------------------------------------------------
-- This script can be freely used and modified as long as [ETW-FZ] and the 
-- original authors are mentioned.
-- dont forget to share your work!
--------------------------------------------------------------------------------
module_name    = "ET:Ask" -- Enemy Territory Anti Spawn killing module
module_version = "0.83"

--------------------------------------------------------------------------------
-- DESCRIPTION
--------------------------------------------------------------------------------
-- ET:Ask aims to reduce spawnkilling (SK) on public funservers. An SK here is if
-- someone kills an enemy near a fix spawn point. A fix spawn point means that
-- it can not be cleared by the enemy. E.g. on radar map, the allied Side Gate 
-- spawn is not fix as the axis can destroy the command post. However, the Main
-- Bunker spawn is fix after the Allies have destroyed the Main Gate. ET:Ask does
-- not prevent but it detects and counts SKs for every player. If a player has
-- caused a certain number of SKs, he gets punished (putspec, kick, ban, ...).
-- As the detection of fix spawns is difficult especially on custom maps, little
-- configuration work has to be done.
--
-- Features:
--     - circular protection areas around spawn points
--     - the spawn protection expires when a player hurts an enemy
--       (can be disabled)
--     - fully configurable for individual maps: fixing radius, positions;
--       adding actions that change protected areas during the game; adding new
--       protection areas.

--------------------------------------------------------------------------------
-- Necromancer: notes
-- a player can mount mg-42's, tanks, and other stuff inside the spawn area
-- and even shoot them, and still have his spawnshield.
-- if the ETWsk_expires flag is on, then the spawnshield will get off when he hurts the enemy.

-- CONFIG
-- NOTE: fs_home path must be set in the server command-line to the ET working directory (where the ET and ETDED resides) for the mod to work!
--------------------------------------------------------------------------------
ETWsk_defaultradius = 400       -- default protection radius
ETWsk_savemode = 1               -- if enabled, protection is only active on
                                 -- maps that are configured
ETWsk_expires = 1                -- if enabled, spawn protection expires when
                                 -- the player hurts an enemy

g_spawnInvulFair = 1		-- Removes the spawn protection when the player fires his first shot (any player, at any spawn)

ETWsk_mapSpawns = 'mapSpawns' -- the folder where all the mapSpawns configs are defind. (under the working mod)
				    -- the path is relative to the ET installation, as set in the fs_home path

ETask_print_spawns = 0		-- print the spawn's info into the console&log. info is needed to map and configure map-spawns for protection.
				-- it will also give you shield as long as in spawn, so you can walk in and out to see exactly where the end of the protection.





	    
-------------------------------------------------------------------------------- 
maxcheckpointdist = 800          -- used to detect capturable flag poles
--------------------------------------------------------------------------------
-- END OF CONFIG SECTION

--[[-------------------------------------
-- CHANGELOG --

-- 0.82
	** added: range command
	** add: et_print checks to prevent players messing up the spawns
	** add: ETask_print_spawns toggle to help map spawn areas


--]]





-- CONSTANTS
NO_PROTECT     = 0
PROTECT_AXIS   = 1
PROTECT_ALLIES = 2
--------------------------------------------------------------------------------

-- global veriables
player_sig = {} -- player's "spawn signature" (his ammo table and damage-given)


-- load compiled chunk
local f = pcall(loadfile(et.trap_Cvar_Get("fs_homepath") .. '/' ..et.trap_Cvar_Get("gamename") .. '/' .. "ETaskc.ua"))

--------------------------------------------------------------------------------
function getConfig(map)
--[[--------------------------------------------------------------------------------
-- configures protection of spawn areas in specific maps
--------------------------------------------------------------------------------
--	create a new file, named <mapname>.lua  wheres <mapname> is the map name (.bsp file) of the map
--		<spawn definitions>
--		<action definitions>
--
--	look at existing mapSpawns settings to get a live working reference.
--------------------------------------------------------------------------------
-- spawn definitions:
--      c.spawn[<spawn-num>] = {<spawn-fields>}
-- spawn-num: spawn index (see /etwsk_spawns command)
-- spawn-fields: - comma-separated list of "key = value"
--               - for existing spawns all fields are optional (they overwrite
--                 default values).
--               - fields:
--                     name = <String>  : name of spawn point
--                     state = NO_PROTECT|PROTECT_ALLIES|PROTECT_AXIS
--                     pos = {x,y,z}    : map coordinates of spawn point 
--                     radius = <Int>  : protection radius for normal weapons
-- action definitions: actions are definitions of transitions of one state of a
--                     spawn point into another one triggered by a message.
--      c.action[<action-num>] = {<action-fields>}
-- action-num: just an increment number
-- action-fields: - comma-separated list of "key = value"
--                - all fields are mandatory
--                - fields:
--                     spawn = <spawn-num>
--                     newstate = NO_PROTECT|PROTECT_ALLIES|PROTECT_AXIS
--                     trigger = <String>: part of a message that is displayed
--                                         by the server on a specific event.
-- adding new protection areas to maps:
--     new protection areas can easily been added:
--     1. enter the map and walk to the location where you want to add the area
--     2. type /etwsk_spawns and remember the highest spawn index number
--     3. type /etwsk_pos and write down the coordinates
--     4. add spawn to config with at least the name,state and pos field
-- default values:
--     At mapstart, ET:Ask scans for all spawnpoints and sets the state either to
--     PROTECT_ALLIES or PROTECT_AXIS. It also scans for capturable flag poles
--     and sets the state of a spawnpoint near a flag pole to NO_PROTECT. The
--     location of a spawnpoint is taken from the WOLF_objective entity, the
--     small spawn flag that can be selected in the command map. This entity is
--     usually placed in the center of the individual player-spawnpoints.
--     However, on some maps this is not the case. Check the positions of the
--     small spawn flags on the command map or type /etwsk_pos after you have
--     spawned to check the distance to protected areas. If needed, adjust the 
--     radius, or the pos or add a new protection area to the map.
--     If you wish to set all protection areas manually in a map, add:
--         c.defaults = false
--     to the definitions for a map.

Necromancer:
use  ETask_print_spawns = 1 to print information about all available spawn points on the map into the console.
next, you can configure those spawns as you like in the mapSpawns/mapname.lua
local c = {spawns = {}, actions = {}, defaults = true} -- a must have line

use this to override existing spawn properties:
c.spawns[spawn_number] = {pos = {-1827, 2254, 128}, state = NO_PROTECT, radius = 500}
spawn_number - the spawn's number
pos = the {X,Y,Z} coordinates of the spawn, if the spawn position is not corrent, you can use the 
/viewpos command in-game (client side) to get your corrent position, and use it to override the spawn position.
state - do we protect some1?
radius - the radius of protection around this spawn point.

-- actions -- 
c.actions[action_number] = {spawn = 3, newstate = PROTECT_ALLIES, trigger = "breached the Old City wall"}
action_number - the action's number (you choose)
spawn - the number of the spawn this action regards to.
newstate - the new state of protection.
trigger - what text triggers this action.

best way to understand all this is to look at live examples. (and play with it alittle)
i used oasis.lua in this description, check out how it works, play with it alittle, and you'll get it.
note that i corrected the allied spawn point position.



new command that should also help in mapping
/range 
in console, will print you the distance from you (player) to the closesnt spawnpoint (real or fake) that matches your team. (it will calculate the distance from closest axis spawn for an axis player...)
it helps alot in mapping, because you can walk all the way where you want the spawn protection to be active, and then type /range, and you know what value you should set the radius field for the protection to expend to that point.
makes mapping spawns alot easier.

it is also recommanded to use sv_cheats 1 (forcecvar, or use devmap map_name to load the map in dev mode, where you can use cheats)
then look at yourself in 3rd person with cg_thirdperson 1, and see when exactly your spawn shield disappear. 
with ETask_print_spawns on it will give you back the spawnshield when you walk into the spawn area, so you can pin-point the spawn area.

--------------------------------------------------------------------------------]]
	local filename = et.trap_Cvar_Get("fs_homepath")
	filename = filename .. '/' ..et.trap_Cvar_Get("gamename") .. '/' ..  ETWsk_mapSpawns .. '/' .. map .. ".lua"

	hasconfig = false 
	setSpawns = nil
	local f = pcall(loadfile(filename))

	
	if (f == true ) then
		
		if  type(f) ~= "function" then
			f = assert(loadfile(filename))
		end
		pcall(f) -- define the setSpawns function
		if (type(setSpawns) ~= "function") then -- the setSpawns function is not defind in that script

			local fd = io.open( filename, "r")
			local filestr =  fd:read("*a")
			fd:close()

			-- for some reason this code doesnt work in some cases... etpro says "cannot malloc -1 bytes" - forward to the etpro team?
			--local fd,len = et.trap_FS_FOpenFile( 'kmod/commands/' .. command .. ".lua", et.FS_READ )
			--if (len > 0) then
			--et.G_Print(command .. "\n")
			--local filestr = et.trap_FS_Read( fd, len ) 
			assert(loadstring('function setSpawns() ' .. filestr .. "\nend","f"))() -- wrap the file in the dolua(params) function, and run the chunk (define the function)

		end


		if (type(setSpawns) == "function") then
			hasconfig = true -- we got a map spawn config!
			--return setSpawns() -- run the code
			--et.G_Print("map defined!\n")
		else
			
			et.G_LogPrint("ET:Ask - no spawns defined for map " ..map.. "\n" )
		end



	else  -- the file does not exist (or any other error loading the file)
		et.G_LogPrint("ET:Ask - no spawns defined for map " ..map.. "\n" )
	end	

end


--------------------------------------------------------------------------------
-- called when client types a command like "/command" on console
function et_ClientCommand(cno, command) 
--------------------------------------------------------------------------------
-- commands: 
--     ET:Ask        : prints mod info and current spawnkill statistics
--     etwsk_spawns : prints list of spawnpoints with current state
--     etwsk_pos    : prints current position and distances to protected spawns
--------------------------------------------------------------------------------
    local cmd = string.lower(command) 
    if cmd == "etwsk_spawns" then 
        printSpawns(cno)
        return 1 
    elseif cmd == "etwsk_pos" then
        printPos(cno)
        return 1
    elseif cmd == "range" then
	printRange(cno)
	return 1
    -- Necromancer: Removed
    --elseif cmd == "ET:Ask" then
    --   printStats(cno)
    --    return 1
    end 
    return 0 
end 

--------------------------------------------------------------------------------
-- calculates the distance
-- note: not true distance as hight is doubled. So the body defined by constant
--       distance is not a sphere, but an ellipsoid
function calcDist(pos1, pos2)
--------------------------------------------------------------------------------
	local dist2 = (pos1[1]-pos2[1])^2 + (pos1[2]-pos2[2])^2 
                  + ((pos1[3]-pos2[3])*2)^2
    return math.sqrt(dist2)
end
    

function printRange(client)
	local player_pos = et.gentity_get(client, "r.currentOrigin")
	local dist
	local radius
	local minimum = 50000
	for i,spawn in pairs(c.spawns) do
		if spawn.state == et.gentity_get(client, "sess.sessionTeam") then
			radius = spawn.radius
			dist = calcDist(player_pos, spawn.pos)
			if (minimum > dist) then
				minimum = dist
			end
		end
	end
          et.trap_SendServerCommand(client, string.format("print \"^4ETW^2sk:^7 distance from closest spawn ^3%d  \n\"", minimum))
end
--------------------------------------------------------------------------------
-- called at map start
function et_InitGame( levelTime, randomSeed, restart)
--------------------------------------------------------------------------------
    local modname = string.format("%s v%s", module_name, module_version)
    et.G_Print(string.format("%s loaded\n", modname))
    et.RegisterModname(module_name)

    mapname = et.trap_Cvar_Get("mapname")
    getConfig(mapname) -- load the map config!
    if ETWsk_savemode == 1 and hasconfig == false then
	return -- dont use the default config
    else
	if type(setSpawns) == "function" then
		c = setSpawns()
	else
		c = {spawns = {}, actions = {}, defaults = true}
	end
    end
    damagegiven = {}
    spawnkills = {}
    
    local checkpoints = {}
    -- find capturable flag poles
    for i = 64, 1021 do
        if et.gentity_get(i, "classname") == "team_WOLF_checkpoint" then			
            table.insert(checkpoints,i)
        end
    end
	-- complete config with default extracted values
    local spawn = 1
    for i = 64, 1021 do
        if et.gentity_get(i, "classname") == "team_WOLF_objective" then
		local pos = et.gentity_get(i, "origin");
    		if c.spawns[spawn] == nil then 
			c.spawns[spawn] = {} end
		if c.spawns[spawn].name == nil then 
			c.spawns[spawn].name = et.gentity_get(i, "message") end
		if c.spawns[spawn].pos == nil then 
			c.spawns[spawn].pos = et.gentity_get(i, "origin") end
		if c.spawns[spawn].state == nil then 
			local iscapturable = false
			for k,v in pairs(checkpoints) do
            			local cp = et.gentity_get(v, "origin")
				if(calcDist(c.spawns[spawn].pos, cp) <= 
				  maxcheckpointdist) then
					iscapturable = true
				end
			end
			if iscapturable then
				c.spawns[spawn].state = NO_PROTECT
			else
				if et.trap_Cvar_Get("gamename") == "etpub" then -- etpub doesnt have G_GetSpawnVar() yet
					c.spawns[spawn].state = tonumber(et.gentity_get(i, "spawnflags"))
					
				else
					c.spawns[spawn].state = tonumber(et.G_GetSpawnVar(i, "spawnflags"))
				end
				
			end
		end
		if ETask_print_spawns ~= nil and ETask_print_spawns ~= 0 then
			local spawn_name = ""
			if c.spawns[spawn].state == 1 then
				spawn_name = "axis"
			elseif  c.spawns[spawn].state == 2 then
				spawn_name = "allies"
			else
				spawn_name = "No Protection"
			end

			et.G_LogPrint("spawn - number:" .. spawn  .. " PROTECT:" ..spawn_name .." origin:" .. c.spawns[spawn].pos[1] .. " " .. c.spawns[spawn].pos[2] .." " .. c.spawns[spawn].pos[3]   .. " name:" ..c.spawns[spawn].name ..  "\n" )
		end
		if c.spawns[spawn].radius == nil then
			c.spawns[spawn].radius = ETWsk_defaultradius end
		spawn = spawn + 1
        end
    end
    -- auto complete spawns
    for i,spawn in pairs(c.spawns) do
	if spawn.radius1 == nil then
		spawn.radius1 = ETWsk_defaultradius1 end
	if spawn.radius2 == nil then
		spawn.radius2 = ETWsk_defaultradius2 end
    end
end



function et_ClientSpawn(slot, revived )
--------------------------------------------------------------------------------
	if (revived == 1) then
		player_sig[slot]["spawn"] = 0
		return
	end


	if ETWsk_savemode == 1 and hasconfig == false then
		return -- dont use the default config
	end
	player_sig[slot] = {}
	player_sig[slot]["team"] = et.gentity_get(slot, "sess.sessionTeam")
	player_sig[slot]["primary"] = et.gentity_get(slot,"ps.ammoclip",tonumber(et.gentity_get(slot,"sess.latchPlayerWeapon")))
	player_sig[slot]["weapon_table"] = getAmmoTable(slot)
	player_sig[slot]["secondary"] = et.gentity_get(slot,"ps.ammoclip",tonumber(et.gentity_get(slot,"sess.latchPlayerWeapon2")))
	player_sig[slot]["current"] = et.gentity_get(slot,"s.weapon")
	if player_sig[slot]["team"] == 1 then -- axis
		player_sig[slot]["granades"] =  et.gentity_get(slot,"ps.ammoclip", 23) -- WP_KAR98

	else -- allies
		player_sig[slot]["granades"] = et.gentity_get(slot,"ps.ammoclip", 9) -- WP_GRENADE_PINEAPPLE
	end
	player_sig[slot]["damage"] = et.gentity_get(slot, "sess.damage_given")
	player_sig[slot]["protect"] = 1
	player_sig[slot]["spawn"] = 1





	if(player_sig[slot]["damage"] == nil) then player_sig[slot]["damage"] = 0 end

end

--------------------------------------------------------------------------------
function printSpawns(cno)
--------------------------------------------------------------------------------
    if hasconfig == false then
	et.trap_SendServerCommand(cno, 
			"print \"^4ETW^2sk:^7 no config for this map!\n\"")
		if ETWsk_savemode == 1 then
		et.trap_SendServerCommand(cno, 
				"print \"^4ETW^2sk:^7 protection deactivated (savemode)!\n\"")
		end
    end
    local protect = {}
    protect[0] = "NO_PROTECT"
    protect[1] = "^1PROTECT_AXIS"
    protect[2] = "^4PROTECT_ALLIES"
    if cno >= 0 then 
        et.trap_SendServerCommand(cno, 
			"print \"^4ETW^2sk:^7 Mapname: ^3"..mapname.."\n\"")
    end  
    for i,spawn in pairs(c.spawns) do
        if cno == -1 then et.G_Printf(
			"ET:Ask> Spawn %d \"%s\" %s \n", i, spawn.name, protect[spawn.state])
        else et.trap_SendServerCommand(cno, "print \"^4ETW^2sk:^7 Spawn ^3"..
			i.."^7 "..spawn.name.." "..protect[spawn.state].."\n\"")
		end
    end
end

--------------------------------------------------------------------------------
function printPos(cno)
--------------------------------------------------------------------------------
    local pos = et.gentity_get(cno, "r.currentOrigin")
    local spos = string.format('%d, %d, %d',
		unpack(pos))
    et.trap_SendServerCommand(cno, 
		"print \"^4ETW^2sk:^7 current pos: "..spos.."\n\"")
    local team = et.gentity_get(cno, "sess.sessionTeam")
    local protect_normal = "^2protected_normal"
    local protect_heavy = "^2protected_heavy_only"
    for i,spawn in pairs(c.spawns) do
	local protect = "^1not protected"
        if spawn.state == team then
            local dist = calcDist(pos, spawn.pos)
            if dist < spawn.radius1 then 
				protect = protect_normal
            elseif dist < spawn.radius2 then
				protect = protect_heavy
			end
            et.trap_SendServerCommand(cno, string.format(
                "print \"^4ETW^2sk:^7 spawn ^3%d (%s): %s ^7distance: %d \n\"",
                i, spawn.name, protect, dist))
        end
    end     
end


--------------------------------------------------------------------------------
-- called when someone has been killed
function et_Obituary(victim, killer, meansOfDeath)
--------------------------------------------------------------------------------
    if ETWsk_savemode == 1 and hasconfig == false then
	return -- dont use the default config
    end
	
    if ETWsk_expires == 1 then
		if killer ~= 1022 then -- not "world"
			player_sig[killer]["protect"] = 0 -- cancel the shield of the killing player, just in case
		end
    end
end


--------------------------------------------------------------------------------
-- printf wrapper
function et.G_Printf(...)
--------------------------------------------------------------------------------
    et.G_Print(string.format(unpack(arg)))
end


function et_RunFrame( levelTime )
	mtime = tonumber(levelTime)
	if hasconfig == false then -- map doesnt got a config
		if ETWsk_savemode == 1 then
			return
		end
	end
	local ammo
	local temp 
	for i=0, tonumber(et.trap_Cvar_Get("sv_maxclients"))-1, 1 do
		if player_sig[i] ~= nil then
			if player_sig[i]["team"] == 1 or player_sig[i]["team"] == 2 then
				if ETask_print_spawns > 0 then
					if inSpawn(i) ~= 0 then
						et.gentity_set(i,"ps.powerups", 1, mtime + 100 )
					end
				end

				if player_sig[i]["protect"] == 1 then
					
					if inSpawn(i) == 0 then -- check if the client is no longer in the spawn area
						player_sig[i]["protect"] = 0 -- should not be protected anymore
						--et.G_Print(" out of spawn\n")
					end
				end

				if  tonumber(et.gentity_get(i,"ps.powerups", 1 )) > 0 then -- if the guy has a spawnshield
					-- check if you picked-up a diffrent weapon
					--if tonumber(et.gentity_get(i,"sess.latchPlayerWeapon")) ~= tonumber(et.gentity_get(i,"sess.playerWeapon")) then
					--	player_sig[i]["primary"] = et.gentity_get(i,"ps.ammoclip",tonumber(et.gentity_get(i,"sess.playerWeapon"))) -- set in the ammo clip of the new weapon
						
				
					-- i cant find how to check whats the weapon the player holds right now (not spawns with)
					-- so i cant check for a weapon-switch.
					-- workaround: check old ammot table versus new ammo table.

					-- lets check if the current ammoclip is the same as when you spawned. if not, you are firing bullets
					ammo = getAmmoTable(i)
					temp = weaponStatus(ammo, player_sig[i]["weapon_table"])
					if player_sig[i]["current"] ~=  et.gentity_get(i,"s.weapon") and temp == 2 then -- switched weapon
						player_sig[i]["weapon_table"] = ammo
						player_sig[i]["current"] = et.gentity_get(i,"s.weapon")
					elseif temp == 2 then -- lost ammo = weapon fired
						if ETWsk_expires == 1 then -- the user did damage since he spawned
							player_sig[i]["protect"] = 0
						end
						if g_spawnInvulFair > 0 and player_sig[i]["spawn"] == 1 then et.gentity_set(i,"ps.powerups", 1, 0 ) end -- remove the spawnshield right away!!! (and player_sig[i]["spawn"] == 1 // remove the spawnshield only if player spawned. we dont want to remove a spawnshield from revived player)
						--et.G_Print("weapon fired\n")
					elseif temp ~= 0 then -- either picked up a new weapon, or gained ammo (picked up ammo pack)
						--et.G_Print("picked up a new weapon (or ammo)\n")
						player_sig[i]["weapon_table"] = ammo
					
					elseif player_sig[i]["damage"] ~=  et.gentity_get(i, "sess.damage_given") then
						if ETWsk_expires == 1 then -- the user did damage since he spawned
							player_sig[i]["protect"] = 0 -- should not be protected anymore
						end
						if g_spawnInvulFair > 0 and player_sig[i]["spawn"] == 1 then et.gentity_set(i,"ps.powerups", 1, 0 ) end -- remove the spawnshield right away!!!
						--et.G_Print("3!\n")
					else
						if player_sig[i]["protect"] == 1 then
							-- protect
							--et.G_Print("protected!\n")
							et.gentity_set(i,"ps.powerups", 1, mtime + 100 ) -- add another half-second to the spawn shield
						end

					end
					player_sig[i]["current"] = et.gentity_get(i,"s.weapon")

				end
			end
		end
	end
end


function inSpawn(slot) -- returns 1 if the player inside a protected spawn, or 0 otherwise
	local player_pos = et.gentity_get(slot, "r.currentOrigin")
	local dist
	local radius
	for i,spawn in pairs(c.spawns) do
--[[
		for k,v in pairs(spawn) do
			if type(v) ~= "table" then
				et.G_Print("key - " ..k .. " value - " .. v .."\n")
			else
				for k1,v1 in pairs(v) do
					et.G_Print("key1 - " ..k1 .. " value1 - " .. v1 .."\n")
				end
			end
		end
--]]	
		if spawn.state == player_sig[slot]["team"] then
			
			radius = spawn.radius
			--et.G_Print("radius - " ..radius .. "\n")
			dist = calcDist(player_pos, spawn.pos)
			--et.G_Print("location player: " ..player_pos[1] .. " " .. player_pos[2] .. " " .. player_pos[3] ..  "\n")
			--et.G_Print("location spawn: " ..spawn.pos[1] .. " " .. spawn.pos[2] .. " " .. spawn.pos[3] ..  "\n")
			--et.G_Print("destination - " ..dist .. "\n")

			if(dist <= radius) then -- player is inside the spawn
				return 1
			end
		end
		
	end
	return 0 -- player is outside the spawn
end

function et_ClientDisconnect( clientNum)
	player_sig[clientNum] = nil
end

-- retrives the slot's ammo table
function getAmmoTable(slot)
	local ammo={}
	for i=1, 48, 1 do
		ammo[i]={}
		-- ammo in the current clip
		ammo[i]["clip"] = et.gentity_get(slot,"ps.ammoclip",i)
		-- ammo in other clips
		ammo[i]["ammo"] = et.gentity_get(slot,"ps.ammo",i)
	end
	return ammo
end





-- recives old ammo table, and new ammo table
-- returns 0 if nothing changed, 1 if gained ammo, 2 if lost ammo, 3 if changed weapon (or picked up an empty weapon) EDIT: oops, i only check the current clip, not the whole weapon ammo -> this function will return 1 only if gained ammo into the current clip (panzer ammo etc...)
function weaponStatus(current_ammo,new_ammo)
	count = 1
	flag = 0 -- ammo increase?
	local weapon = {}
	for i=1, 48, 1 do
		if current_ammo[i]["clip"] ~= new_ammo[i]["clip"] then
			if  current_ammo[i]["clip"] > new_ammo[i]["clip"] then
				flag = 1
			end
			weapon[count] = i
			count = count +1
		end
	end
	if weapon[2] ~= nil then
		return 3 -- picked up a new weapon
	elseif weapon[1] == nil then
		return 0 -- nothing changed
	elseif weapon[1] ~= nil and flag == 1 then
		return 1
	else return 2 end
end


