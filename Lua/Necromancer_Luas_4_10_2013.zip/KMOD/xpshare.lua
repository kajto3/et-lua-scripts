-------------------------------------
-------	   ETpub XP Sharing  --------
-------    By Necromancer    --------
-------      5/19/2009       --------
-------   www.usef-et.org    --------
-------------------------------------

-- this module allows XP sharing across different ETpub and No Quarter servers.
-- install: set g_XPSaveDirectory to a directory where to save the players XP. this is an absulute path (just like No Quarter)
-- add "xpsave.lua" to the lua_modules cvar in all your servers.
-- after conversion the server should start with g_XPSaveFile set to a filename with ".converted" suffix so that the module wont convert it again

-- note: ETpub servers will still use that shrubbot for storing map statistics, player statistics and even player XP.
-- if the XP on the server does not mach the XP loaded from the shared-xp file, the shared-xp file will take priority and the player's xp will be updated.

-- this module writes an No Quarter like xp file, thus allowing to share XP between No Quarter and ETpub mods.

-- does not support off-server XPdecay yet.

-- this module was not tested in real-life condition.
-- please report bugs, suggestions and feedback to www.usef-et.org -> forums -> kmod+


--et.trap_Cvar_Set("g_XPSaveDirectory",'E:\\Games\\Wolfenstein - Enemy Territory\\noquarter\\xpsave')
-- TODO: xpdecay, file size test

BATTLESENSE = 0
ENGINEERING = 1
MEDIC = 2
SIGNALS = 3
LIGHT_WEAPONS = 4
HEAVY_WEAPONS = 5
COVERT = 6

--[[
-- from No Quarters g_xpsave.h

// Lucel: XP save structure. We read/write this directly to disk.
//
// We don't care about padding issues as the structure will be padded
// consistently on the same machine - if we want to share these across different
// platforms then we might need to deal with padding.

#define XP_SAVE_SIGNATURE 		0x0ACED00D
#define XP_SAVE_CUR_VER			0
#define XP_SAVE_FILE_EXT		".xp"
#define MAX_GUID_LENGTH			32

typedef struct {
	int			signature;					// Check it's a valid save file
	int			version;					// Check file version. Allow for backwards compatibility later on.
	time_t		timestamp;					// Timestamp of xp save file
	char		netname[MAX_NETNAME];		// Store the player name
	float		skillpoints[SK_NUM_SKILLS];	// skillpoints
} g_xpsave_t;

--]]
-- NQ Constants
SIGNATURE = "0x0ACED00D"
VERSION = 0
MAX_NETNAME = 36

SIGNATURE_INT = 181325837 -- this is the SIGNATURE in decimal value, so we wont need to convert it from hex

-- C data types and their number of bytes
INTEGER = 4
FLOAT = 4
TIME_T = 4

WINDOWS = 8
LINUX = 4


SYSTEM = WINDOWS



-- windows time_t is 8 bytes long, while linux's is only 4 bytes long
local s,e,linux
linux = et.trap_Cvar_Get("version")
s,e = string.find(linux,"linux",1,1)
if s and e then
	SYSTEM = LINUX
end

PLAYERS = {}

function et_ClientBegin( slot )
	PLAYERS[slot] = tonumber(et.gentity_get(slot,"sess.sessionTeam"))
	readxp(slot)

end

function et_ClientUserinfoChanged( slot )
	if  tonumber(et.gentity_get(slot,"sess.sessionTeam")) ~= PLAYERS[slot] then -- player changed team
		writexp(slot)
		PLAYERS[slot] = tonumber(et.gentity_get(slot,"sess.sessionTeam"))
	end
end
		

function readxp(slot)
	local guid = string.upper(et.Info_ValueForKey( et.trap_GetUserinfo( slot ), "cl_guid" ))
	if guid == "UNKNOWN" then
		et.G_LogPrint("xpshare error: unknown guid\n")
		return
	end
	local filename = et.trap_Cvar_Get("g_XPSaveDirectory") .. '/' .. guid .. ".xp"
	local handle, err
	handle,err = io.open(filename,"r")
	if handle == nil then
		et.G_Print("xpshare error: ".. err .. "\n")
		return
	end
	local filestr = handle:read("*a") 
	handle:close() 
	
	if string.len(filestr) ~= INTEGER + INTEGER + SYSTEM + MAX_NETNAME + FLOAT*7 then
		et.G_LogPrint("xpshare error: " ..  guid .. ".xp wrong file size (" .. string.len(filestr) .. "/" .. INTEGER + INTEGER + SYSTEM + MAX_NETNAME + FLOAT*7 .. ")\n")
		return
	end

	local struct = Binary(filestr)
	local skillpoints,skill = {}
	local signture,version,name
	signture = string.upper(string.format("%x", struct.BinaryToInteger(INTEGER))) -- take the integer, convert to hex, turn to upper case chars and add 0x to it.
	signture = "0x" .. string.rep("0",8-string.len(signture)) .. signture
	version = struct.BinaryToInteger(INTEGER)
	time_t = struct.BinaryToInteger(SYSTEM)
	name = struct.BinaryToString(MAX_NETNAME)
	if signture ~= SIGNATURE or version ~= VERSION then
		et.G_LogPrint("xpshare error: " ..  guid .. ".xp wrong file signture or version\n")
		--if signture ~= SIGNATURE then
		--	et.G_LogPrint("xpshare error: signture doesnt mach " ..  signture .. "-" ..SIGNATURE .. " " .. string.len(signture) .. "-" .. string.len(SIGNATURE) .. "\n")
		--end
		return
	end
	skillpoints[BATTLESENSE] = struct.BinaryToFloat()
	skillpoints[ENGINEERING] = struct.BinaryToFloat()
	skillpoints[MEDIC] = struct.BinaryToFloat()
	skillpoints[SIGNALS] = struct.BinaryToFloat()
	skillpoints[LIGHT_WEAPONS] = struct.BinaryToFloat()
	skillpoints[HEAVY_WEAPONS] = struct.BinaryToFloat()
	skillpoints[COVERT] = struct.BinaryToFloat()
	
	--[[
	et.G_LogPrint("name " .. name .. "\n")
	et.G_LogPrint("skillpoints[BATTLESENSE] " .. skillpoints[BATTLESENSE] .. "\n")
	et.G_LogPrint("skillpoints[ENGINEERING] " .. skillpoints[ENGINEERING] .. "\n")
	et.G_LogPrint("skillpoints[MEDIC] " .. skillpoints[MEDIC] .. "\n")
	et.G_LogPrint("skillpoints[SIGNALS] " .. skillpoints[SIGNALS] .. "\n")
	et.G_LogPrint("skillpoints[LIGHT_WEAPONS] " .. skillpoints[LIGHT_WEAPONS] .. "\n")
	et.G_LogPrint("skillpoints[HEAVY_WEAPONS] " .. skillpoints[HEAVY_WEAPONS] .. "\n")
	et.G_LogPrint("skillpoints[COVERT] " .. skillpoints[COVERT] .. "\n")
	--]]


	for skill=BATTLESENSE,COVERT,1 do -- the classes are numbered from 0 to 6 (7 total, 5 + battle sense + light weapons)
		if not nearXP(et.gentity_get( slot, "sess.skillpoints", skill),skillpoints[skill]) then -- XP update is needed!
			--[[
			if et.gentity_get( slot, "sess.skillpoints", skill) ~= 0 then -- dont reset the skillpoints if they are already on 0!
				et.G_LoseSkillPoints(slot, skill, et.gentity_get( slot, "sess.skillpoints", skill)) -- making use of the G_LoseSkillPoints function just for pheno :)
			end
			et.G_AddSkillPoints(slot, skill, skillpoints[skill]) 
			--]]
			et.G_AddSkillPoints(slot, skill, skillpoints[skill] - et.gentity_get( slot, "sess.skillpoints", skill)) -- add [file.xp] - [server_xp]
			--et.G_LogPrint("added " ..skillpoints[skill] ..  " to skill number " .. skill .."\n")
		end
	end
	--et.G_LogPrint("xpshare: total xp of  " ..skillpoints[BATTLESENSE] + skillpoints[ENGINEERING] + skillpoints[MEDIC] + skillpoints[SIGNALS] + skillpoints[LIGHT_WEAPONS] + skillpoints[HEAVY_WEAPONS] + skillpoints[COVERT]..  " was loaded!\n")
end

function et_ClientDisconnect(slot)
	writexp(slot)
	PLAYERS[slot] = nil
end

function writexp(slot)
	local guid = string.upper(et.Info_ValueForKey( et.trap_GetUserinfo( slot ), "cl_guid" ))
	local name = et.gentity_get(slot,"pers.netname")

	if guid == "UNKNOWN" then
		et.G_LogPrint("xpshare error: unknown guid\n")
		return
	end

	local skillpoints = {}
	local skill
	for skill=BATTLESENSE,COVERT,1 do -- get the slot's skill points
			skillpoints[skill] = et.gentity_get( slot, "sess.skillpoints", skill)
	end


	local filename = et.trap_Cvar_Get("g_XPSaveDirectory") .. '/' .. guid .. ".xp"
	handle,err = io.open(filename,"wb")
	if handle == nil then
		et.G_Print("xpshare error: ".. err .. "\n")
		return
	end

	local struct = Binary("")
	local signture
	handle:write(struct.IntegerToBinary(SIGNATURE_INT))
	handle:write(struct.IntegerToBinary(VERSION))
	handle:write(struct.IntegerToBinary(os.time()))
	if SYSTEM == WINDOWS then
		handle:write(struct.IntegerToBinary(0))
	end
	handle:write(struct.stringToBinary(et.Q_CleanStr(name)))
	handle:write(struct.FloatToBinary(skillpoints[BATTLESENSE]))
	handle:write(struct.FloatToBinary(skillpoints[ENGINEERING]))
	handle:write(struct.FloatToBinary(skillpoints[MEDIC]))
	handle:write(struct.FloatToBinary(skillpoints[SIGNALS]))
	handle:write(struct.FloatToBinary(skillpoints[LIGHT_WEAPONS]))
	handle:write(struct.FloatToBinary(skillpoints[HEAVY_WEAPONS]))
	handle:write(struct.FloatToBinary(skillpoints[COVERT]))
	handle:flush()
	handle:close()	
	--et.G_LogPrint("xpshare: total xp of  " ..skillpoints[BATTLESENSE] + skillpoints[ENGINEERING] + skillpoints[MEDIC] + skillpoints[SIGNALS] + skillpoints[LIGHT_WEAPONS] + skillpoints[HEAVY_WEAPONS] + skillpoints[COVERT]..  " was written\n")
end

function reWriteShrubbot()
	--re-write the shrubbot.cfg file and change his name
	local filename = et.trap_Cvar_Get("g_XPSaveFile")
	if filename == "" or string.find(filename,".converted",1,1) then return end --xpsave file does not exists or was already converted
	line = {}
	line = LoadFileToTable(filename)
	if line == nil then return end

	local s,e
	local i

	local r
	local guid,ttime,name
	


--[[
[xpsave]
guid              = 786B915A04B23F1D7EE32FBDB9959EED
name              = ^0wArmUp
time              = 1242491741
skill[0]          = 1850.254883
skill[1]          = 330.024811
skill[2]          = 127.833466
skill[3]          = 19.000000
skill[4]          = 809.497925
skill[5]          = 99.333450
skill[6]          = 47.999809
kill_rating       = -0.016127
kill_variance     = 0.006829
rating            = -0.066588
rating_variance   = 0.703443
pr_skill[0]       = 0 0.000000 0 0.000000 0 0.000000 0 0.000000 11 -0.211662
pr_skill[1]       = 0 0.000000 0 0.000000 0 0.000000 1 0.017715 3 -0.131418
pr_skill[2]       = 0 0.000000 1 -0.075758 0 0.000000 2 -0.254912 0 0.000000
pr_skill[3]       = 2 0.000592 1 0.163458 0 0.000000 0 0.000000 0 0.000000
pr_skill[4]       = 0 0.000000 0 0.000000 0 0.000000 0 0.000000 11 -0.211662
pr_skill[5]       = 1 -0.020775 1 0.232358 2 -0.006196 1 -0.071355 0 0.000000
pr_skill[6]       = 0 0.000000 0 0.000000 2 -0.065370 0 0.000000 0 0.000000
--]]

	for r=1,table.getn(line),1 do
		s,e,tguid = string.find(line[r], "guid%s*= ([^%\n]*)")
		if s and e and tguid then
			guid = trim(tguid)
			skillpoints = {}
			skillpoints[BATTLESENSE] = 0
			skillpoints[ENGINEERING] = 0
			skillpoints[MEDIC] = 0
			skillpoints[SIGNALS] = 0
			skillpoints[LIGHT_WEAPONS] = 0
			skillpoints[HEAVY_WEAPONS] = 0
			skillpoints[COVERT] = 0
		end
		if skillpoints ~= nil then
			--et.G_LogPrint(line[r] .. "\n")

			s,e,tname = string.find(line[r], "name%s*= ([^%\n]*)")
			if tname then name = trim(tname) end
			
			s,e,temp_time = string.find(line[r], "time%s*= ([^%\n]*)")
			if temp_time then ttime = trim(temp_time) end

			
			s,e,battlesense = string.find(line[r], "skill\%[0]%s*= ([^%\n]*)")
			if s == 1 and battlesense then skillpoints[BATTLESENSE] = trim(battlesense) end

			s,e,engineering = string.find(line[r], "skill\%[1]%s*= ([^%\n]*)")
			if s == 1 and engineering then skillpoints[ENGINEERING] = trim(engineering) end

			s,e,medic = string.find(line[r], "skill\%[2]%s*= ([^%\n]*)")
			if s == 1 and medic then skillpoints[MEDIC] = trim(medic) end

			s,e,signals = string.find(line[r], "skill\%[3]%s*= ([^%\n]*)")
			if s == 1 and signals then skillpoints[SIGNALS] = trim(signals) end

			s,e,light_weapons = string.find(line[r], "skill\%[4]%s*= ([^%\n]*)")
			if s == 1 and light_weapons then skillpoints[LIGHT_WEAPONS] = trim(light_weapons) end

			s,e,heavy_weapons = string.find(line[r], "skill\%[5]%s*= ([^%\n]*)")
			if s == 1 and heavy_weapons then skillpoints[HEAVY_WEAPONS] = trim(heavy_weapons) end

			s,e,covert = string.find(line[r], "skill\%[6]%s*= ([^%\n]*)")
			if s == 1 and covert then skillpoints[COVERT] = trim(covert) end

			s,e,empty = string.find(line[r],"(%S+)")
			if not s then -- empty line, means a block end
				--et.G_LogPrint("empty line:" .. empty .."\n")
				--[[
				et.G_LogPrint("----> Here <----------\n")
				if guid then et.G_LogPrint("got guid ") end
				if name then et.G_LogPrint("got name ") end
				if ttime then et.G_LogPrint("got time ") end
				if atLeastOneSkill(skillpoints) then et.G_LogPrint("got skill \n") end
				et.G_LogPrint("\n")
				--]]
				if guid and name and ttime and atLeastOneSkill(skillpoints) then
					-- write file
					filename = et.trap_Cvar_Get("g_XPSaveDirectory") .. '/' .. guid .. ".xp"
					--[[
					fd,len = et.trap_FS_FOpenFile(filename , et.FS_WRITE )
					if len < 0 then
						et.trap_FS_FCloseFile( fd )
						et.G_Print("ERROR - XPsave: unable to open XPsave file for guid " .. guid .. "\n")
						return
					end
					--]]
					local handle, err
					handle,err = io.open(filename,"wb")
					if handle == nil then
						et.G_Print("xpshare error: ".. err .. "\n")
						return
					end

					local struct = Binary("")
					local signture
					handle:write(struct.IntegerToBinary(SIGNATURE_INT))
					handle:write(struct.IntegerToBinary(VERSION))
					handle:write(struct.IntegerToBinary(os.time()))
					if SYSTEM == WINDOWS then
						handle:write(struct.IntegerToBinary(0))
					end
					handle:write(struct.stringToBinary(et.Q_CleanStr(name)))
					handle:write(struct.FloatToBinary(skillpoints[BATTLESENSE]))
					handle:write(struct.FloatToBinary(skillpoints[ENGINEERING]))
					handle:write(struct.FloatToBinary(skillpoints[MEDIC]))
					handle:write(struct.FloatToBinary(skillpoints[SIGNALS]))
					handle:write(struct.FloatToBinary(skillpoints[LIGHT_WEAPONS]))
					handle:write(struct.FloatToBinary(skillpoints[HEAVY_WEAPONS]))
					handle:write(struct.FloatToBinary(skillpoints[COVERT]))
					handle:flush()
					handle:close()	

					-- delete our block so we wont write it again
					guid = nil
					name = nil
					ttime = nil
					skillpoints[BATTLESENSE] = 0
					skillpoints[ENGINEERING] = 0
					skillpoints[MEDIC] = 0
					skillpoints[SIGNALS] = 0
					skillpoints[LIGHT_WEAPONS] = 0
					skillpoints[HEAVY_WEAPONS] = 0
					skillpoints[COVERT] = 0
				end
			end
		end
	end -- we ran over all of the xpsave file
	et.G_LogPrint("XPsave file converted!\n")
	-- rename it so we wont convert it again
	et.trap_FS_Rename( et.trap_Cvar_Get("g_XPSaveFile"), et.trap_Cvar_Get("g_XPSaveFile") .. ".converted" )
	et.trap_Cvar_Set("g_XPSaveFile",et.trap_Cvar_Get("g_XPSaveFile") .. ".converted")

	
end
		

function et_InitGame( levelTime, randomSeed, restart )
	reWriteShrubbot()
end
	
function et_ShutdownGame( restart )
	local name,slot
	for slot=0, tonumber(et.trap_Cvar_Get("sv_maxclients"))-1, 1 do
		name = et.gentity_get(slot,"pers.netname")
		if name == nil or name == "" then 
			-- skip
		else
			writexp(slot) -- write xp at map end/reset/restart (it is being read on map start, as all the client begin the game, if its not saved, the xp doesnt get updated and people stuck with their xp without being able to gain new xp)
		end
	end
end

-- credits
OLD = os.time()
function et_RunFrame( levelTime )
	if math.fmod (os.time(),12780) == 0 and os.time() - OLD > 1 then -- print credits once every 3.33 hours
		et.trap_SendServerCommand( -1 , string.format('%s \"%s"\n',"bp","^hth^mi^hs se^mr^hver is ru^mni^hng xp^msh^ha^mre ^hv^me^hrsi^mon ^h1^m.^h0 by ^wNe^zcr^9o^0m^9a^znc^wer"))
		et.G_LogPrint("xpshare: visit www.usef-et.org\n")
		OLD = os.time()
	end
end




function nearXP(current,old) -- returns 1 if the current xp is equal or close enough to the old xp
	if current == old then return 1 end -- equal!
	if math.abs(current - old) <= 10  then return 1 end -- the old xp is inside a range of +/- 10 XP, its close enough
	return nil
end

function trim(str)
	local tstr
	s,e,tstr = string.find(str,"([^%\r]*)")
	if tstr == nil or tstr == str then
		s,e,tstr = string.find(str,"([^%\n]*)")
	end
	if tstr == nil then return str 
	else return tstr end
end



function LoadFileToTable(filename) -- loads a file into a table where table[i] = line
	
	local fd, len = et.trap_FS_FOpenFile( filename , et.FS_READ )
	if (len < 0 or len == nil) then
		et.G_Print("xpshare error: unable to open xpsave file " .. filename .."\n")
		return
	end
	
	local i=1
	local file = {}
	local line = ""
	local filestr = et.trap_FS_Read( fd, len )
	for line in string.gfind(filestr, "([^%\n]*)\n") do
		file[i] = line
		i=i+1
	end
	et.trap_FS_FCloseFile( fd )
	return (file)	
end

function atLeastOneSkill(skillpoints)
	if skillpoints[BATTLESENSE] == 0 and skillpoints[ENGINEERING] == 0 and skillpoints[MEDIC] == 0 and skillpoints[SIGNALS] == 0 and skillpoints[LIGHT_WEAPONS] == 0 and skillpoints[HEAVY_WEAPONS] == 0 and skillpoints[COVERT] == 0 then
		return nil
	else
		return 1
	end
end


function xpdecay(xp) -- calculates the xp after decay

end




function Binary(strin)
	local str = strin

	--[[ all available functions *within* this ADT:
	BinaryToInteger(num) -- reads num binary bytes out of the string, and converts them into an integer
	BinaryToString(num)  -- reads num binary bytes out of the string, and converts them into a string
	bitsToInteger(bits)  -- converts the binary string bits into an integer
	bitsToIntegerRemainder(bits) -- converts the binary string bits into an integer's remainder
	BinaryToFloat() -- reads a binary float out of the string, and converts it to numrical float

	IntegerToBits(num)   -- converts the integer num into a binary form
	IntegerRemainderTobits(num) -- converts the integer remainder into binary remainder
	FloatToBits(num)     -- converts a float into a binary represintation
	
	stringToBinary(str)  -- doesnt do anything except padding the string with 0 so that the total length will be 36 (propobly should not be here)
	IntegerToBinary(num) -- converts the integer to binary bytes
	FloatToBinary(num)   -- converts the float to binary bytes
	--]]

	local BinaryToInteger = function (num) 
		local bytee
		local i
		local base = 8
		local number = 0
		for i=0,num-1,1 do
			bytee = string.byte(str, 1)
			--et.G_Print("bytee: " .. bytee .. "\n")
			number = number + bytee * 2^(i*base)
			--et.G_Print("number: " .. number .. "\n")
			str = string.sub (str, 2)
		end
		return number
	end

	local BinaryToString = function (num) 
		local bytee
		local i
		local base = 8
		local number = 0
		local message = ""
		for i=0,num-1,1 do
			bytee = string.byte(str, 1)
			--et.G_Print("i: " .. i .." bytee: " .. bytee .. "\n")
			--number = number + bytee * 2^(i*base)
			message = message .. string.char(bytee)
			--et.G_Print("i: " .. i .." message: " .. message .. "\n")
			str = string.sub (str, 2)
		end
		return message
	end

--[[
	local BinaryToInteger = function () -- converts binary integer number to number
		local byte1, byte2, byte3, byte4
		byte1, byte2 = string.byte(str, 1, 2)
		byte3, byte4 = string.byte(str, 3, 4)
		local temp = string.format("%d", byte1 * 2^0 + byte2 * 2^8 + byte3 * 2^16 + byte4 * 2^24)
		str = string.sub (str, 5) -- update the string (cut out the converted item)
		return temp
	end


	local HexToString = function () -- converts binary hexadecimal number to string
		local byte1, byte2, byte3, byte4
		byte1, byte2 = string.byte(str, 1, 2)
		byte3, byte4 = string.byte(str, 3, 4)
		local temp = string.format("%x", byte1 * 2^0 + byte2 * 2^8 + byte3 * 2^16 + byte4 * 2^24)
		temp = "0x" .. string.upper(temp)
		str = string.sub (str, 5) -- update the string (cut out the converted item)
		return temp

	end

	local TimeToString = function () -- converts binary time_t timestamp to string
		local byte1, byte2, byte3, byte4, byte5, byte6, byte7, byte8
		byte1, byte2 = string.byte(str, 1, 2)
		byte3, byte4 = string.byte(str, 3, 4)
		local temp = string.format("%x", byte1 * 2^0 + byte2 * 2^8 + byte3 * 2^16 + byte4 * 2^24  )
		temp = "0x" .. string.upper(temp)
		str = string.sub (str, 9) -- update the string (cut out the converted item)
		return temp

	end
--]]


	local IntegerToBits = function (num)
		-- returns a string 8 charactars long, representing the 8 bits in the given byte
		--et.G_Print("number: " .. num .. "\n")
		local bit
		local bits = ""
		local fraction
		local base = 2
		while (num > 0) do
			fraction = math.fmod (num, base)
			bits = bits .. fraction
			num = math.floor (num/2)
		end
		fraction = math.fmod (num, base)
		if fraction > 0 then
			bits = bits .. fraction
		end
		bits = string.reverse(bits)
		--et.G_Print("bits: " .. bits .. " len: ".. string.len(bits) .. "\n")
		return bits
	end

	local bitsToInteger = function(bits)
		--et.G_Print("bits: " .. bits .. "\n") 
		local bits = string.reverse(bits)
		local bit 
		local number = 0
		local base = 2
		local i = 0
		repeat 
			bit = string.sub(bits, 1,1)
			bits = string.sub(bits, 2)
			--et.G_Print("i : " .. i .. " bits: " .. bits .. "\n") 
			number = number + bit*(base^i)
			--et.G_Print("i : " .. i .. " number: " .. number .. " bits: " .. bits .. "\n") 
			i = i+1
		until string.len(bits) == 0
		return number
	end
			


	local bitsToIntegerRemainder = function (bits)
		local bit 
		local number = 0
		local base = 2
		local i = -1
		while string.len(bits) > 0 do
			bit = string.sub(bits, 1,1)
			bits = string.sub(bits, 2) 
			number = number + bit*(base^i)
			--et.G_Print("i : " .. i .. " number: " .. number .. " bits: " .. bits .. "\n") 
			i = i-1
		end
		return number
	end
	-- converting floating point to/from binary
	-- http://justin.madirish.net/node/171
	local BinaryToFloat = function () -- float assumes to be always 32 bytes. (4 bytes)
		local bits32 = BinaryToInteger(4)
		--et.G_Print("Binary-float: " .. bits32 .. "\n")
		bits32 = IntegerToBits(bits32)
		bits32 = string.rep("0",32 - string.len(bits32)) .. bits32 -- append following 0's if the number is too short
		--if string.len(bits32) ~= 32 then -- in that case, bit32 should be 31 bits long. 8 exponent bits + 23 fraction bits. the sign bit is 0 and got truncted by the BinaryToInteger() function (does not append following zeros)
		--	bits32 = "0"..bits32
		--end
		if bits32 == "00111111100000000000000000000000" then return 0 end -- 0 xp (otherwise the float calculation will return 1)
		--et.G_Print("Integer-float: " .. bits32 .. "\n")
		--et.G_Print("bits32: " .. bits32 .. " len: ".. string.len(bits32) .. "\n")
		local sign = string.sub(bits32, 1,1) -- the sign is ignored (xp can only be positive)
		local exponent = string.sub(bits32, 2,9)
		local fraction = string.sub(bits32, 10)
		local integer, remainder
		--et.G_Print("sign : " .. sign .. " exp: " .. exponent .. " frac: " ..fraction .. " len: " .. string.len(fraction) .. "\n") -- time_t timestamp
		--et.G_Print("exponent : " .. exponent .. "\n") 
		exponent = bitsToInteger(exponent) - 127 
		--et.G_Print("exponent : " .. exponent .. "\n") 
		
		-- CODE REPLACED (look lower)
		--fraction = "1." .. fraction
		--fraction = tonumber(fraction) -- seems like lua supports only 14-15 digits after the . (dot, fraction), so the number gets cut down. use only strings.
		--et.G_Print("fraction : " .. fraction .. "\n") 
		--fraction = fraction *(10^exponent) -- un-normalize
		--et.G_Print("fraction : " .. fraction .. "\n") 

		local remainder_int
		local remainder_frac
		remainder_int = string.sub(fraction,1, exponent)
		remainder_frac = string.sub(fraction, exponent+1)
		fraction = "1" .. remainder_int .. "." .. remainder_frac
		--et.G_Print("fraction : " .. fraction .. "\n") 
		local s,e = string.find(fraction, ".",1,1)
		integer = bitsToInteger(string.sub(fraction, 1,s-1))
		remainder = bitsToIntegerRemainder(string.sub(fraction, s+1))
		--et.G_Print("integer : " .. integer .. " remainder: " .. remainder .."\n") 

		return tonumber(integer + remainder)
	end

	local IntegerRemainderTobits = function (num)
		local bit
		local bits = ""
		local fraction
		local integer
		local base = 2
		num = num*base
		while (num > 0 and string.len(bits) <32 ) do
			if num >= 1 then
				bits = bits .. "1"
				num = num -1
			else
				bits = bits .. "0"
			end
			num = num*base
		end
		--bits = bits .. fraction
		--bits = string.reverse(bits)
		--et.G_Print("bits: " .. bits .. " len: ".. string.len(bits) .. "\n")
		return bits
	end

	local FloatToBits = function (num)
		local integer
		local remainder
		local number, exponent 
		local s,e
		local old,new,temp
		--if num == 0 then return "00000000000000000000000000000000" end
		exponent = 0
		integer,remainder = math.modf(num)
		--et.G_Print("integer: " .. integer .. " remainder: ".. remainder .. "\n")
		integer = IntegerToBits(integer)
		--integer = tonumber(integer) -- remove any leading 0's
		s,e = string.find(integer,"1")
		if s and e then
			integer = string.sub(integer,s)
		end

		remainder = IntegerRemainderTobits(remainder)
		-- now we need to normalize the fraction
		number = integer .. "." .. remainder
		
		-- CODE REPLACED (look lower)
		--while tonumber(number) > 2 do
		--	number = number / 10
		--	exponent = exponent +1
		--end

		-- now cut out the first 1. 
		--number = string.sub(number,3)

		--et.G_Print("number: " .. number .. "\n")
		old = string.find(number,".",1,1) -- find position of the . in the number
		temp = string.sub(number,1,old-1) -- integer part
		number = temp .. string.sub(number,old+1) -- fraction part (removes the dot from number)
		s,e = string.find(number,"1")
		--et.G_Print("number: " .. number .. " s: ".. s .. " old: " .. old .. "\n")
		if s and e then
			exponent = old-1 -s
			number = string.sub(number,s+1) -- removes the leading 1
		else -- number is 0.0 (0)
			exponent = 0
		end
		--et.G_Print("number: " .. number .. " exponent: ".. exponent .. "\n")

		--  cut if too long
		if string.len(number) > 23 then
			number = string.sub(number,1,23)
		end
		-- padd with 0's if too short
		number = number .. string.rep("0",23 - string.len(number))
		--et.G_Print("number: " .. number .. " exponent: ".. exponent .. "\n")
		-- now add a sign bit (0) and the exponent
		exponent = IntegerToBits(exponent + 127)
		--et.G_Print("number2: " .. number .. " exponent: ".. exponent .. "\n")
		number = "0" .. exponent .. number
		--et.G_Print("number: " .. number .. "\n")
		return number


	end

	local stringToBinary = function (str)
		local binary = ""
		-- pad with \0 (NULL's) if too short
		binary = str .. string.rep('\0',36 - string.len(str))
		return binary
	end

			
	local IntegerToBinary = function (num) -- assumes Integer is 4 bytes
		local bytes = 4
		local base = 8
		local binary = ''
		local bytee
		local i
		--et.G_Print("number: " .. num .. "\n")
		for i=0,bytes-1,1 do
			bytee = num / 2^(base*i)
			bytee = bytee % 256
			--et.G_Print("bytee0: " .. bytee .. "\n")
			bytee = math.floor(bytee) -- only integer values, trunc the fraction (if the fraction is used, it doesnt get it right. when the floats exponent is being calculated, it returns wrong value)
			--et.G_Print("bytee " .. bytee .. "\n")
			binary = binary .. string.char(bytee)
			--et.G_Print("binary: " .. binary .. "\n")

		end
		return binary
	end

	local FloatToBinary = function (num)
		local binary
		--et.G_Print("Float-Integer num: " .. num .. "\n")
		binary = FloatToBits(num) -- first convert it to binary
		--et.G_Print("Float-Integer: " .. binary .. "\n")
		binary = bitsToInteger(binary) -- now reconstruct a number from the binary float (just like the float was first converted to binary)
		--et.G_Print("Float-Integer: " .. binary .. "\n")
		binary = IntegerToBinary(binary)
		return binary
	end
		
		

	return {
		--BinaryToNumber = BinaryToNumber,
		--HexToString = HexToString,
		BinaryToInteger = BinaryToInteger, -- BinaryToInteger
		BinaryToString = BinaryToString,
		BinaryToFloat = BinaryToFloat,

		--FloatToBits = FloatToBits,
		--IntegerToBits = IntegerToBits,

		IntegerToBinary = IntegerToBinary,
		FloatToBinary = FloatToBinary,
		stringToBinary = stringToBinary

	}
end