-- !levlist

function dolua(params) 

	if params.slot ~= CONSOLE then
		-- make it look like the player has used the command in chat
		userPrint(params.slot,params.chat,et.ConcatArgs(1),-1)
	end

	et.trap_SendServerCommand( params.slot, params.say.." \"^wLevel ^10^w: ^2G^8uest ^wLevel ^11^w: ^2Regular ^8Player ^wLevel ^12^w: ^2Muppet ^8Friend ^wLevel ^13^w: ^2Tryout ^8Member ^wLevel ^14^w: ^8Member ^wLevel ^15^w: ^2Admin ^7\"" )

	return 1
end