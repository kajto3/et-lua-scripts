function dolua(params)
	ignore(params["slot"], et.trap_Argv(1))
end