function dolua(params)
	unignore(params["slot"], et.trap_Argv(1))
end