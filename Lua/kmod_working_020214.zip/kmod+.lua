-- KMOD+ By Necromancer
-- Dummy file
dofile(et.trap_Cvar_Get("fs_basepath") .. '/etpro/kmod+/core/kmod+.lua') -- fire!


